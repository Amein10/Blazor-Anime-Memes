﻿namespace BlazorApp1.Data
{
    public class Anime
    {
        public int Id { get; set; }
        public string name { get; set; }
        public string url { get; set; }
    }
}